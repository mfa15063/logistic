import './bootstrap';
import '../../public/admin/vendor/apexcharts/apexcharts.min.js';
import '../../public/admin/vendor/bootstrap/js/bootstrap.bundle.min.js';
import '../../public/admin/js/main.js';
