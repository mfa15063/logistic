<!-- Modal Body -->
<div class="modal fade" id="uniquemodel" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false" role="dialog"
    aria-labelledby="modalTitleId" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-body">
                <div class="text-center">
                    <span class="success-icon py-3 px-3">
                        <?php if(session('type') == 'success'): ?>
                        <i style="font-size: 80px; color: #23bf23b5;" class="bi bi-check2-circle"></i>
                        <?php elseif(session('type') == 'error'): ?>
                        <i style="font-size: 80px;color:#ff0000ad;" class="bi bi-x-circle"></i>
                        <?php endif; ?>
                        </span>
                </div>
                <div class="text-center my-2 mb-2">
                    <h3 class="model_title">
                        <?php echo e(session('message')); ?>

                    </h3>
                    <button type="button" class="btn btn-secondary col"
                        data-bs-dismiss="modal">Close</button>
                    <?php if(!$slot->isEmpty()): ?>
                        <?php echo e($slot); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Your other content -->
<?php if(session('type')): ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var myModal = new bootstrap.Modal(document.getElementById('uniquemodel'));
            myModal.show();
        });
    </script>
<?php endif; ?>
<?php /**PATH C:\Users\Admin\Documents\PhpstormProjects\logistic\not_final_admin\resources\views/components/model.blade.php ENDPATH**/ ?>